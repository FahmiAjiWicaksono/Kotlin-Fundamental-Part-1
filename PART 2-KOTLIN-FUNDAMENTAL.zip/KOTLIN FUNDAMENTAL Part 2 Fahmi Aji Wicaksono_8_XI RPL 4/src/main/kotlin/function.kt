fun main() {
    val nama = "Fahmi"
    val hobi = "Playing Football"
    val umur : Int = 16
    setUser(nama, hobi, umur)
}

fun setUser(nama : String ,  hobi: String , umur: Int){
    println ("My name is $nama, I like $hobi, and I'm $umur years old.")
}
