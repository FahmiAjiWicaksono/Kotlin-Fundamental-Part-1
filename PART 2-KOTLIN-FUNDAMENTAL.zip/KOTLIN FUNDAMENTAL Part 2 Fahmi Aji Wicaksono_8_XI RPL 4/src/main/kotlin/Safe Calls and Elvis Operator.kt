fun main() {
    var word : String? = "SMK Telkom"
    var WordLength = word?.length
    print("Jumlah kata dari string SMK Telkom sebanyak $WordLength")
}
