fun main() {
    val nilai: Int = 82
    if (nilai >= 75) {
        println("Nilai kamu $nilai, Selamat ya!")
    } else {
        println("Nilai kamu $nilai, Silahkan ikut remidial.")
    }
}













