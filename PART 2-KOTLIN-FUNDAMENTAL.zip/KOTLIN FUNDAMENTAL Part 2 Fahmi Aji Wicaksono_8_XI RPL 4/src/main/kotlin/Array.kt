fun main() {
    val mixArray = arrayOf(30, "Januari", 1993, "SMK Telkom Purwokerto", true)

    print ("\n"+mixArray[3]+ " "+"Lahir pada tanggal"+" " +mixArray[0]+" "+mixArray[1]+" "+mixArray[2]+ " That's "+mixArray[4]+" Bro.")
}

