fun main(args: Array<String>) {
    val firstWorld : String = "SMK"
    val midleWorld : String = "Telkom"
    val lastWold : String = "Purwokerto"

    val panjang : Int = 10
    val lebar : Int = 5
    val luas : Int = panjang * lebar;

    println(firstWorld + " " + midleWorld + " " + lastWold);
    println ("Luas Persegi panjang " +luas);
}
