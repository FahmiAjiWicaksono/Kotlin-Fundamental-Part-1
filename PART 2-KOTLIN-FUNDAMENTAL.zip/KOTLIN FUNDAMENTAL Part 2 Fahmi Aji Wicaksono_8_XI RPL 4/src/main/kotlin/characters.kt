fun main() {
    var vocal = 'Z';

    println("Vocal " + vocal--);
    println("Vocal " + vocal--);
    println("Vocal " + vocal);
    vocal = vocal - 5
    println("Vocal " + vocal--);
    println("Vocal " + vocal++);
    println("Vocal " + vocal);
    vocal = vocal + 5
    println("Vocal " + vocal++);
    println("Vocal " + vocal++);
    println("Vocal " + vocal);
}



