fun main(args: Array<String>) {
    val nama = "Fahmi Aji Wicaksono"
    val hobi = "Bermain Sepak Bola"

    println ("Nama saya " + nama);
    println ("Hobi saya " + hobi);
}