fun main() {
     var vocal = 'Z'

    println("Huruf " + vocal--)
    println("Huruf " + vocal--)
    println("Huruf " + vocal--)
    vocal--
    vocal--
    vocal--
    vocal--
    println("Huruf " + vocal--)
    println("Huruf " + vocal++)
    println("Huruf " + vocal++)
    vocal++
    vocal++
    vocal++
    vocal++
    println("Huruf " + vocal++)
    println("Huruf " + vocal++)
    println("Huruf " + vocal++)



}